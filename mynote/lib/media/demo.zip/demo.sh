#!/usr/bin/env bash

# * * * * * /bin/bash /Users/yourname/bin/mynotes_sync.sh >/dev/null 2>&1 &
# nohup bash /Users/yourname/bin/mynotes_sync.sh >/dev/null 2>&1 &
# windows unison "D:\demo1"  "D:\demo2" -perms 0o1622 -fastcheck true  -batch -auto -silent -repeat watch+3600  -retry 3 -ignore "Name .git"


# 监控的根目录和批处理文件
main_dir="/Users/yourname/我的笔记"
webdav_dir="/Volumes/dav/我的笔记"
unison="/usr/local/bin/unison"

# 如果进程已经存在，直接退出
SCRIPT_NAME=$(basename "$0")
if [ "$(pgrep -fl "$SCRIPT_NAME")" ]; then
    echo "${SCRIPT_NAME}进程已存在"
    exit 0
fi

# 循环检查目录是否存在
while true; do
    # 判断 $webdav_dir 是否存在
    if [ -d "$webdav_dir" ]; then
        # 判断 $main_dir 是否存在
        if [ -d "$main_dir" ]; then
            # 如果两个目录都存在，则退出循环并执行后续命令
            echo "will start unison"
            break
        fi
    fi
    # 如果任意一个目录不存在，则等待一段时间后再次检查
    echo "waiting for $webdav_dir and $main_dir"
    sleep 5
done

# 启动unison
ignores=(-ignore 'Name .DS_Store' -ignore 'Name .git' -ignore 'Name .cache' -ignore 'Name .obsidian' -ignore 'Name .trash' -ignore 'Name ._.*' -ignore 'Name .tmp' -ignore 'Name .lock')

#这里必须安装https://github.com/autozimu/unison-fsmonitor才能用watch
$unison "$main_dir" "$webdav_dir" -perms 0o1622 -fastcheck true -batch -auto -silent -repeat watch+3600 -retry 3 "${ignores[@]}"


# 命令行参数解释如下：
# -batch：批处理模式，不显示用户界面。
# -auto：自动处理冲突，选择“预测的”动作。
# -silent：静默模式，不输出非错误信息。
# -repeat watch：监控源目录的变化，如有变化则重新同步。
# -ignore 'Pattern'：指定要忽略的文件或目录的模式。您可以根据需要添加多个 -ignore 参数来忽略不同的文件或目录。
# 请注意，Unison 的同步是双向的，它会自动检测两个文件夹中的更改并同步它们。如果出现冲突，Unison 会尝试合并更改，但在某些情况下可能需要用户干预来决定如何处理冲突。

